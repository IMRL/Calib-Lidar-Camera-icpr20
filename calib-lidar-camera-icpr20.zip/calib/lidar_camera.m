close all; 
dbstop error; 
clear;
addpath(genpath(pwd))
% 3D point
image_point = importdata('camera_point.mat');
lidar_point = importdata('lidar_point.mat');

% icp
[tform,~] = pcregrigid(pointCloud(lidar_point),pointCloud(image_point));
extrinsic = (tform.T).';

% 3D-2D
intrinsic = [importdata('camera_K.mat') [0 0 0].'];
cali = intrinsic * extrinsic;

% plot
img_frame = imread('020.png');
lidar_frame = importdata('lidar_020.mat');
figure(1);
imshow(img_frame,'border','tight','InitialMagnification','fit');
set (gcf,'Position',[0,0,1280,720]);
axis normal;
hold on;

lidar_img = project(lidar_frame(:,1:3),cali);
for i=1:size(lidar_img,1)
  plot(lidar_img(i,1),lidar_img(i,2),'o','LineWidth',1,'MarkerSize',1,'Color',[1,0,0]);
end
hold off;