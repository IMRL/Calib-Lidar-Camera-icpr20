%% checkerboard from the lidar data, points fusion of multiple views
function points_lidar=points_from_lidar()

%lidars=importdata('lidar_point.mat');
points_lidar=[];

for i=1:15
    lidarname=[num2str(i),'.pcd'];
    ptCloud = pcread(['E:\data\lidar\20191219\',lidarname]);
    velo = ptCloud.Location;
    
    idx = velo(:,1)<2;
    velo(idx,:) = [];
    idx = velo(:,1)>20;
    velo(idx,:) = [];
    idx = velo(:,2)<-9;
    velo(idx,:) = [];
    idx = velo(:,2)>5;
    velo(idx,:) = [];
%     idx = velo(:,3)>1;
%     velo(idx,:) = [];

    ptCloud = pointCloud(velo);
    maxDistance = 0.04;
    referenceVector = [0,0,1];
    maxAngularDistance = 30;
    [~,inlierIndices,~] = pcfitplane(ptCloud,maxDistance,referenceVector,maxAngularDistance);
    
    plane=select(ptCloud,inlierIndices);
    figure;pcshow(plane);
    
    velo=plane.Location;
    points_lidar=[points_lidar;velo];
end

save('lidar_point.mat','lidar_all');