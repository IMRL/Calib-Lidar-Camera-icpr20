%% checkerboard points in the camera coordinate
function points_camera=points_from_camera()
A = importdata('cameraParams.mat');
R = A.RotationMatrices;
T = A.TranslationVectors/1000;

points_camera = [];
p1=importdata('checker.mat');

for i = 1:15
    points_camera = [points_camera R(:,:,i).'*p1+T(i,:).'];
end

save('camera_point.mat','points_camera');  
